package characters;

import java.util.ArrayList;
import java.util.List;

import ball.AbleToDraw;
import ball.Pattern;
import ball.Surface;

public class Tubik implements AbleToDraw {

    private final List<Pattern> patterns = new ArrayList<>();

    public void addPattern(Pattern pattern) {
        patterns.add(pattern);
    }

    @Override
    public void draw(Surface surface) {
        if (!surface.ready()) {
            throw new IllegalStateException("Поверхность не готова!");
        }
        patterns.forEach(u -> System.out.println("Тюбик рисует " + u));
    }
}
