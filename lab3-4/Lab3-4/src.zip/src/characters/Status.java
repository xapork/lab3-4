package characters;
public enum Status {
    FOUND,
    LOST,
    REEDUCATED,
    UNKNOWN


}
