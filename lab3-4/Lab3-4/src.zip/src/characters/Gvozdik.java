package characters;

import exception.GlassBreakingException;

public class Gvozdik extends Citizen {

    private boolean reeducated = true;

    public Gvozdik() {
        super("Gvozdik");
    }

    @Override
    public void doSmt() {
        System.out.println("Gvozdik ведет себя прилично");
    }

    public void битьСтекла() throws GlassBreakingException{
        if (reeducated) {
            throw new GlassBreakingException();
        }
    }
}
