package Main;
import java.time.LocalDate;
import java.util.List;

import ball.*;
import ball.enviroment.*;
import characters.*;

public class Main {

    public static void main(String[] args) {

        Malysh Malysh = new Malysh("Винтик");
        Malysh.addWork(new Work("Установить фонари"));

        Malyshki Malyshki = new Malyshki();
        Malyshki.addFlowers(new Flowers("Ромашка", "белый"));
        Malyshki.addDecorating(new Decorating("Гирлянда", "золотая"));

        DanceFloor floor = new DanceFloor("большая");
        Tent tent = new Tent("синяя");
        
        Tubik Tubik = new Tubik();
        Tubik.addPattern(new Pattern("Цветочный", 8));
        Tubik.addPattern(new Pattern("Музыкальный", 6));

        Pavilion pavilion = new Pavilion();
        pavilion.бытьРасписанной(Tubik);
        pavilion.принятьОркестр();


        PrepForBall ball = new PrepForBall(
                List.of(floor, tent, Malyshki, Malysh)
        );

        ball.start();

        InfAboutBall инфо = new InfAboutBall(
                LocalDate.now(),
                "Цветочный город",
                "18:00",
                ball.getReadiness()
        );

        System.out.println("" + инфо);
    }
}
