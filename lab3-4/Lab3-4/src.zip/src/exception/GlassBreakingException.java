package exception;
public class GlassBreakingException extends Exception {
    @Override
    public String getMessage() {
        return "Он все-таки разбил стекла!";
    }
}
