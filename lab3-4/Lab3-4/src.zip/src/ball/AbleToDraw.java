package ball;

public interface AbleToDraw {
    void draw(Surface surface);
}
