package ball;

public interface ReadyPercent {
    int inputBall();
    void prepare();
}
